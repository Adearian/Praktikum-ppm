const mysql = require = require('mysql');

const connection = mysql.createConnection( {
    host: 'localhost',
    user: 'root',
    password:'',
    database: 'kuliah',
});

connection.connect((err) => {
    if (err) {
        console.error('error connecting to MySQL database', err);
    } else {
        console.log('connecting to MySQL database');
    }
    });

    module.exports = connection;
